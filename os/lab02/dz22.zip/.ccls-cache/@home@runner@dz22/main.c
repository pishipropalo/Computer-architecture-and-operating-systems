#include <stdio.h>
#include <stdlib.h>

void john();
void fred();
void bill();
void sam();

int main() {
  
    fred();  
    john();  
    bill(); 
    sam(); 

    return 0;
}
